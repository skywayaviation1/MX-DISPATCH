# White Label Jet MX — Setup Runbook (Phase 1)

No command line. Everything below is done in a web browser.

**Order matters. Do the parts in sequence A → I.**

---

## Part A — GitHub: create the repo and add the files

1. Go to https://github.com/new
2. **Repository name:** type exactly `white-label-jet-mx`
3. Set it **Private**. Do **not** add a README, .gitignore, or license.
4. Click **Create repository**.
5. On the next page click the link **"uploading an existing file"**.
6. From the folder I gave you, drag these in **all at once**:
   - `package.json`
   - `vite.config.js`
   - `index.html`
   - `.gitignore`
   - the entire **`src`** folder (with `App.jsx`, `main.jsx`, `firebase.js`, `index.css` inside it)
   - `SETUP.md`
   - `firestore.rules`
   GitHub keeps the `src/` folder structure when you drag the folder.
7. At the bottom, click **Commit changes**.

> Do **not** worry about `node_modules`. It is intentionally not included — Vercel builds that itself.

---

## Part B — Firebase: create the project

1. Go to https://console.firebase.google.com
2. Click **Create a project** (or "Add project").
3. Name it `white-label-jet-mx` (any name is fine).
4. Google Analytics is optional — turn it off to keep it simple.
5. Click **Create project**, then **Continue** when it finishes.

---

## Part C — Firebase: turn on email/password sign-in

1. Left menu → **Build → Authentication**.
2. Click **Get started**.
3. Open the **Sign-in method** tab.
4. Click **Email/Password**.
5. Turn the **first** toggle **on** (Email/Password). Leave "Email link / passwordless" **off**.
6. Click **Save**.

---

## Part D — Firebase: create the database

1. Left menu → **Build → Firestore Database**.
2. Click **Create database**.
3. Choose **Start in production mode** (we paste real rules next), click **Next**.
4. Pick a location near you — a US region (e.g. `nam5 (United States)` or `us-east1`). **You cannot change this later.** Click **Enable**.

---

## Part E — Firebase: paste the security rules

This is the most important security step. Until you do this, the database is locked and the app will not work; after this, the public can only submit requests and nothing else.

1. In **Firestore Database**, open the **Rules** tab.
2. Select everything in the box and delete it.
3. Open the `firestore.rules` file I gave you, copy **all** of it, paste it in.
4. Click **Publish**.

---

## Part F — Firebase: create YOUR dispatch login

This is two steps: create the sign-in, then authorize it as staff.

**F1 — Create the sign-in account**

1. **Build → Authentication → Users** tab.
2. Click **Add user**.
3. Enter your email and a strong password. Click **Add user**.
4. In the user list, find the row you just made and **copy the User UID**
   (long string like `a1b2c3d4...`). You need it in F2.

**F2 — Authorize that account as an admin**

1. **Build → Firestore Database → Data** tab.
2. Click **Start collection**.
3. **Collection ID:** type exactly `users` → **Next**.
4. **Document ID:** paste the **User UID** you copied in F1.
5. Add these three fields (all type **string**):
   - `email` → your email
   - `name` → your name (e.g. `Jake`)
   - `role` → `admin`
6. Click **Save**.

> Anyone who should reach the dispatch dashboard needs both: (1) an account
> in **Authentication → Users**, and (2) a matching document in the `users`
> collection whose **Document ID is their User UID**. No `users` document =
> "Access pending" screen. This is deliberate — see "Adding staff later."

---

## Part G — Firebase: get the 6 config values

1. Click the **gear icon** (top left, next to "Project Overview") → **Project settings**.
2. Scroll to **Your apps**. Click the **web icon** `</>`.
3. App nickname: `white-label-jet-mx-web`. **Do not** check Firebase Hosting. Click **Register app**.
4. It shows a `firebaseConfig = { ... }` block. Keep this tab open — you copy 6 values from it in Part H.

---

## Part H — Vercel: deploy

1. Go to https://vercel.com and sign in with your GitHub account.
2. **Add New… → Project**.
3. Find `white-label-jet-mx` in the list and click **Import**.
4. Framework Preset should auto-detect **Vite**. Leave build settings default.
5. Expand **Environment Variables** and add these **6** (name on the left, value
   from the `firebaseConfig` block in Part G on the right):

   | Name (type exactly) | Value (from firebaseConfig) |
   |---|---|
   | `VITE_FIREBASE_API_KEY` | `apiKey` |
   | `VITE_FIREBASE_AUTH_DOMAIN` | `authDomain` |
   | `VITE_FIREBASE_PROJECT_ID` | `projectId` |
   | `VITE_FIREBASE_STORAGE_BUCKET` | `storageBucket` |
   | `VITE_FIREBASE_MESSAGING_SENDER_ID` | `messagingSenderId` |
   | `VITE_FIREBASE_APP_ID` | `appId` |

   Copy the values **without** the surrounding quotes.
6. Click **Deploy**. Wait for it to finish, then copy the live URL
   (looks like `https://white-label-jet-mx.vercel.app`).

---

## Part I — IMPORTANT: authorize the Vercel domain (or sign-in fails)

Firebase blocks sign-in from domains it doesn't know. Skip this and staff
sign-in fails with an "unauthorized domain" error.

1. **Firebase → Build → Authentication → Settings** tab → **Authorized domains**.
2. Click **Add domain**.
3. Paste your Vercel domain **without** `https://` (e.g. `white-label-jet-mx.vercel.app`).
4. Click **Add**.
5. If you later connect a custom domain (e.g. via GoDaddy), add that domain here too.

---

## First test

1. Open your Vercel URL. You should see the public **Request maintenance support** form.
2. Fill it out with a test aircraft and **Submit request** — you should get a `REF …` confirmation.
3. Top right → **Staff sign in** → use the email/password from Part F1.
4. You should land on the dashboard with **Requests = 1**. Open it → **Accept & open ticket**.
5. Go to the **Tickets** tab → open the ticket → it shows the locked aircraft
   block with the **Confirm aircraft** button and the certification basis selector.

If sign-in fails, you almost certainly skipped **Part I**.

---

## Adding more dispatch staff later

For each person: repeat **Part F** (F1 to create their Authentication user,
F2 to add their `users` document with their UID). Set `role` to `admin` or
`ops`. (Phase 1 treats both the same; role separation gets wired in later phases.)

---

## Re-skinning for a partner operator (white-label)

- **Name / tagline / logo letters:** top of `src/App.jsx`, the `BRAND` block.
- **Colors:** `src/index.css`, the `:root` block at the very top
  (`--wl-amber`, `--wl-steel`, backgrounds, etc.).

Change those, commit on GitHub, Vercel redeploys automatically.

> Note: this re-skins the single shared app. Giving each partner operator
> their own isolated branded instance and data is a separate architecture
> decision (multi-tenancy) — flagged for a later phase, not built in Phase 1.

---

## What is intentionally NOT in Phase 1

- **Service contract terms.** The plumbing to generate/send/track a contract
  comes in Phase 2; the actual legal language is your aviation attorney's,
  not auto-generated.
- **Dispatch, crews, trucks, parts, ordering, status timeline, signed
  return-to-service record.** Phases 2–3. The data model already reserves
  fields for them so nothing has to be rebuilt.
- **Multi-tenant white-label** (separate instance/data per operator).
- Email/SMS notifications to operators on accept/decline.
